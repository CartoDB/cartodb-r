cartodb.sql<-
function(sql=NULL,urlOnly=FALSE) {
    url <- cartodbSqlApi()
    url <- URLencode(paste(url,"q=",sql,sep=''))
    if (urlOnly==TRUE) return(url)
    cartodb.sql.get<-getURL(url)
    cartodb.sql.json<-fromJSON(cartodb.sql.get[[1]])
    if ( 'rows' %in% names(cartodb.sql.json)) {
        df <- data.frame(t(sapply(cartodb.sql.json$rows[1:length(cartodb.sql.json$rows)],c)))
        return(df)
    } else {
        warning(cartodb.sql.json)
        return(NULL)
    }
}